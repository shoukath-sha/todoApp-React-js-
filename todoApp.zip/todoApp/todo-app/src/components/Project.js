import React, { useState } from 'react';
import TodoList from './TodoList';

const Project = ({ project, updateProjectTitle, updateTodos, exportProjectAsMarkdown }) => {
  const [title, setTitle] = useState(project.title);

  const handleTitleChange = () => {
    updateProjectTitle(project.id, title);
  };

  return (
    <div>
      <h2>
        Project: 
        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          onBlur={handleTitleChange}
        />
      </h2>
      <TodoList todos={project.todos} updateTodos={updateTodos} projectId={project.id} />
      <button onClick={() => exportProjectAsMarkdown(project)}>Export as Gist</button> {/* This should show */}
    </div>
  );
};

export default Project;
