import React, { useState } from 'react';
import { v4 as uuidv4 } from 'uuid';

const TodoList = ({ todos, updateTodos, projectId }) => {
  const [newTodo, setNewTodo] = useState('');

  const addTodo = () => {
    const todo = {
      id: uuidv4(),
      description: newTodo,
      status: false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    updateTodos(projectId, [...todos, todo]);
    setNewTodo('');
  };

  const toggleTodo = (id) => {
    const updatedTodos = todos.map((todo) =>
      todo.id === id ? { ...todo, status: !todo.status, updatedAt: new Date().toISOString() } : todo
    );
    updateTodos(projectId, updatedTodos);
  };

  const removeTodo = (id) => {
    const updatedTodos = todos.filter((todo) => todo.id !== id);
    updateTodos(projectId, updatedTodos);
  };

  return (
    <div>
      <h3>Todos</h3>
      <div style={{ display: 'flex', marginBottom: '10px' }}>
        <input
          type="text"
          value={newTodo}
          onChange={(e) => setNewTodo(e.target.value)}
          placeholder="New Todo"
          style={{ flexGrow: 1, marginRight: '10px' }}
        />
        <button onClick={addTodo}>Add Todo</button>
      </div>
      <ul style={{ listStyleType: 'none', padding: 0 }}>
        {todos.map((todo) => (
          <li className="li2" key={todo.id} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '10px' }}>
            <span style={{ flexGrow: 1 }}>{todo.description}</span>
            <div style={{ display: 'flex', alignItems: 'center' }}>
              <input type="checkbox" checked={todo.status} onChange={() => toggleTodo(todo.id)} />
              <label style={{ marginLeft: '5px' }}>Mark as complete</label>
              <button onClick={() => removeTodo(todo.id)} style={{ marginLeft: '10px' }}>Remove</button>
            </div>
            <span style={{ marginLeft: '10px' }}>{new Date(todo.createdAt).toLocaleDateString()}</span>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default TodoList;

