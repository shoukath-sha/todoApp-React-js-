import React, { useState } from "react";
import { Link } from "react-router-dom";

const Home = ({ projects, setProjects }) => {
  const [newProjectTitle, setNewProjectTitle] = useState("");

  const handleAddProject = () => {
    if (newProjectTitle) {
      const newProject = {
        id: Date.now(), 
        title: newProjectTitle,
        todos: [], 
      };
      setProjects([...projects, newProject]);
      setNewProjectTitle(""); 
    }
  };

  return (
    <div>
      <h1>Your Projects</h1>
      <input
        type="text"
        value={newProjectTitle}
        onChange={(e) => setNewProjectTitle(e.target.value)}
        placeholder="Enter project title"
      />
      <button onClick={handleAddProject}>Add New Project</button>
      <ul>
        {projects.map((project) => (
          <li key={project.id}>
            <Link to={`/project/${project.id}`}>{project.title}</Link>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Home;

