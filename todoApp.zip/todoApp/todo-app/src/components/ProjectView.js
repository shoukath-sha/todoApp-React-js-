import React from 'react';
import { useParams } from 'react-router-dom';
import Project from './Project';

const ProjectView = ({ projects, updateProjectTitle, updateTodos, exportProjectAsMarkdown }) => {
  const { projectId } = useParams();
  const project = projects.find((p) => p.id === parseInt(projectId));

  if (!project) {
    return <div>Project not found</div>;
  }

  return (
    <div>
      <Project
        project={project}
        updateProjectTitle={updateProjectTitle}
        updateTodos={updateTodos}
        exportProjectAsMarkdown={exportProjectAsMarkdown}
      />
    </div>
  );
};

export default ProjectView;


