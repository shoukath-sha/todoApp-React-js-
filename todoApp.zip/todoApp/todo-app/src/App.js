import React, { useState } from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Home from "./components/Home";
import ProjectView from "./components/ProjectView";
import Login from "./components/Auth";

const App = () => {
  const [projects, setProjects] = useState([]);
  const [loggedIn, setLoggedIn] = useState(false);

  const addProject = (title) => {
    const newProject = {
      id: projects.length + 1, // Simple ID generation
      title,
      todos: [],
    };
    setProjects((prevProjects) => [...prevProjects, newProject]);
  };

  const updateProjectTitle = (id, newTitle) => {
    setProjects((prevProjects) =>
      prevProjects.map((project) =>
        project.id === id ? { ...project, title: newTitle } : project
      )
    );
  };

  const updateTodos = (projectId, updatedTodos) => {
    setProjects((prevProjects) =>
      prevProjects.map((project) =>
        project.id === projectId ? { ...project, todos: updatedTodos } : project
      )
    );
  };

  const exportProjectAsMarkdown = (project) => {
    const { title, todos } = project;
    const markdownContent = `
# ${title}

## Todos
${todos.map(todo => `- [${todo.status === "completed" ? "x" : " "}] ${todo.description} (Created on: ${new Date(todo.createdDate).toLocaleString()})`).join('\n')}
    `;
    const blob = new Blob([markdownContent], { type: "text/markdown" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${title.replace(/\s+/g, '_')}_summary.md`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return (
    <Router>
      <div className="container">
        <Routes>
          <Route
            path="/"
            element={loggedIn ? <Home projects={projects} setProjects={setProjects} addProject={addProject} /> : <Login setLoggedIn={setLoggedIn} />}
          />
          <Route
            path="/project/:projectId"
            element={<ProjectView projects={projects} setProjects={setProjects} updateProjectTitle={updateProjectTitle} updateTodos={updateTodos} exportProjectAsMarkdown={exportProjectAsMarkdown} />}
          />
        </Routes>
      </div>
    </Router>
  );
};

export default App;
